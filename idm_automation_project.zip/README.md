# IDM Access Management

Automated FreeIPA IdM user & group management using Ansible integrated with GitLab CI/CD.
Includes:
- User & group management
- System configuration (Nginx)
- Report collection from servers